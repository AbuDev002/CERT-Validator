<?php
	session_start(); 
	require 'helpers/registrationHelpers.php';
    
	
	$name = 'guest';
	$cert_no='';
	
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['cert_no']))
		{
			$validCert = validateCert($_POST);

			if($validCert!=0)
				header('Location:dashbaord.php?err='.$validCert);
				
			if(!certExists($_POST['cert_no']))
			{
				//header('Location:dashboard.php?err=6');
				echo "<script>alert('Certificate Record Not Found')</script>";
				echo "<script>window.open('verify_cert.php','_self')</script>";
			}
			else {
        $cert_no = $_POST['cert_no'];
}
		
		
	/*	else
		{
			return null;
		}*/
			
		}
		else
		{	
			header('Location:dashboard.php?err=4');
		}
		
	}

?>
<?php
include_once("db_connect.php");
$sql = "SELECT uid, username, password, email, account_type FROM users WHERE uid='".$_SESSION['user_session']."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);
?>

<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>
    <div class="container">
      <div class="card">

		  <div class="card-header">
		    <ul class="nav nav-tabs card-header-tabs">
		      <li class="nav-item">
		        <a class="nav-link" aria-current="true" href="dashbaord.php">Dashboard</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" aria-current="true" href="verify_cert.php">Verification</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link active" aria-current="true" href="dashbaord.php">Result</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="logout.php">Sign Out</a>
		      </li>
		     
		    </ul>
		  </div>

		  <div class="card-body">
		   		 <h2 class="form-signin-heading text-center text-muted"><b>Certificate Details</b></h2>
		  <h3 class="form-signin-heading text-center text-muted">
	<?php	  $query = dbConnect()->prepare("SELECT * FROM certificate_details WHERE cert_no=:cert_no");
		
        	$query->bindParam(':cert_no', $cert_no);	
		
		$query->execute();
		
        /*	if($row = $query->fetch())
		{
			return array(
				'name' => $row['name'],
				'cert_no' => $row['cert_no'],
				'cert_date' => $row['cert_date']
			);
		}*/
		while($row = $query->fetch(PDO::FETCH_LAZY)){

    echo '<div>';
    echo $row['name'];
	echo '<br/>';
	 echo $row['cert_type'];
	echo '<br/>';
    echo $row['dept'];
	echo '<br/>';
	 echo $row['cert_grade'];
	echo '<br/>';
    echo $row['cert_date'].'<br/>';
	echo '<br/><a href="cert_template.php?cname='.$row["name"].'&ctype='.$row['cert_type'].'&dept='.$row['dept'].'&cdate='.$row['cert_date'].'&cno='.$row['cert_no'].'&cgrade='.$row['cert_grade'].'">Get Certificate</a>';
    echo '</div>';
		} ?>
		  </h3>
       
		  </div>
		</div>
     
    </div> 
    
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript" src="script/login.js"></script>
<script src="static/js/typeahead.js"></script>	

  </body>
</html>
