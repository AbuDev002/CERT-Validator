<?php
session_start();
include_once("db_connect.php");
if(isset($_POST['login_button'])) {
	$user_email = trim($_POST['user_email']);
	$user_password = trim($_POST['password']);
	
	$sql = "SELECT uid, username, password, email,account_type FROM users WHERE email='$user_email'";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	$row = mysqli_fetch_array($resultset);	
		
	if($row['password']==$user_password){				
		//echo "ok";
		$_SESSION['user_session'] = $row['uid'];
		$_SESSION['account_type'] = $row['account_type'];
		if($row['account_type'] == "employer"){
			echo "employer";
		}elseif($row['account_type'] == "institution"){
			echo "institution";
		}else{
			echo "Account doest not exist";
		}
		exit();
	} else {				
		echo "Email or Password is incorrect."; // wrong details 
	}		
}
?>