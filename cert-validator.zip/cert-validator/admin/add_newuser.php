<?php
session_start(); 
// 	require 'helpers/registrationHelpers.php';
// include_once("db_connect.php");
// $sql = "SELECT uid, username, password, email FROM users WHERE uid='".$_SESSION['user_session']."'";
// $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
// $row = mysqli_fetch_assoc($resultset);

?>
<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="js/adapter.min.js"></script>
<script type="text/javascript" src="js/vue.min.js"></script>
<script type="text/javascript" src="js/instascan.min.js"></script>
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>

    <div id="app" class="container"> 
    	<div class="card">

		  <div class="card-header">
		    <?php include_once('incs/inner_nav.php');?>
		  </div>

		  <div class="card-body">
		    	<!-- <h2 class="form-signin-heading text-center text-muted">Enter Certificate Details</h2> -->
		    	<!-- <div style="display:none" id="result"><g:plusone size="medium"></g:plusone></div> -->
    	<div class="container overflow-hidden">
		  <div class="row">
		    <div class="col-md-8">
		    	<h3>List of Registered Organizations</h3>
		    	<table class="table table-bordered">
		    		<thead>
		    			<tr>
			    			<td><strong>S/N</strong></td>
			    			<td><strong>Name of Organization</strong></td>
			    			<td><strong>Email</strong></td>
			    			<td><strong>Username</strong></td>
			    			
			    		</tr>
		    		</thead>
		    		<tbody id="displayOrgListist">
		    			
		    		</tbody>
		    		
		    	</table>
		    </div>
		    <div class="col-md-4">
		      <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
				  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
			  </div>
		      <div class="p-3 border bg-light">   
		      	<p><strong>Register New Organizations</strong></p>
		        <form id="fupForm" class="form-horizontal"  method="POST">
		        <div class="form-group">
		        	<label>Name of Organization</label>
		        	<input type="text" name="org_name" id="org_name" class="form-control">
		        </div>
		        
		        <div class="form-group">
		        	<label>Email</label>
		        	<input type="text" name="email" id="email" class="form-control">
		        </div>
		    
		        <div class="form-group">
		        	<label>Account Type</label>
		        	<select name="account_type" id="account_type" class="form-control">
		        		<option value="">--Select Account Type--</option>
		        		<option value="employer">Employer</option>
		        		<option value="institution">Institution</option>
		        	</select>
		        </div>
		         <div class="form-group">
		        	<label>Username</label>
		        	<input type="text" name="username" id="username" class="form-control">
		        </div>
		         <div class="form-group">
		        	<label>Password</label>
		        	<input type="password" name="password" id="password" class="form-control">
		        </div>
		        <br>
		        <div class="form-group">
		        	<button class="btn btn-sm btn-success btn-block" id="butsave" type="submit">Create Account</button>

		        </div>
		      </form>
               
		      </div>

		    </div>
		  </div>
		</div>
		  
		  </div>
		</div>

    </div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>


<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript">
   //this function is usded in getting list of Results 
   function loadOrgList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("displayOrgListist").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "fetchOrgList.php", true);
        xhttp.send();
      },2000);
    }
    loadOrgList();
</script>
<script>
$(document).ready(function() {
	$('#butsave').on('click', function() {
		$("#butsave").attr("disabled", "disabled");
		var org_name = $('#org_name').val();
		var email = $('#email').val();
		var account_type = $('#account_type').val();
		var username = $('#username').val();
		var password = $('#password').val();
		if(org_name!="" && email!="" && account_type!="" && username!="" && password!=""){
			$.ajax({
				url: "save_user.php",
				type: "POST",
				data: {
					org_name: org_name,
					email: email,
					account_type: account_type,
					username: username,
					password: password				
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$("#butsave").removeAttr("disabled");
						$('#fupForm').find('input:text').val('');
						$("#success").show();
						$('#success').html('Data added successfully !'); 						
					} else if(dataResult.statusCode==201){
					   alert("Error occured !");
					}	
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});
});
</script> 

</body>
</html>
