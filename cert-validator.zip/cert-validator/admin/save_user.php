<?php
	include_once ('../db_connect.php');
	$org_name=$_POST['org_name'];
	$email=$_POST['email'];
	$account_type=$_POST['account_type'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$sql = "INSERT INTO users (org_name,username,password,email,account_type) VALUES('$org_name','$username','$password','$email','$account_type')";
	if (mysqli_query($conn,$sql)) {
		echo json_encode(array("statusCode"=>200));
	} else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>