<ul class="nav nav-tabs card-header-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="true" href="index.php">Dashboard</a>
  </li>
  <!-- <li class="nav-item">
    <a class="nav-link" aria-current="true" href="verify_cert.php">Verification</a>
  </li> -->
  <li class="nav-item">
    <a class="nav-link" aria-current="true" href="add_newuser.php">Recruiters/Institutions</a>
  </li>
  
  	<li class="nav-item">
        <a class="nav-link" aria-current="true" href="upload_result_details.php">Upload Students Result</a>
    </li>
  <li class="nav-item">
    <a class="nav-link" href="logout.php">Sign Out</a>
  </li>
 
</ul>