$('#process').click(function(){
	//var n = document.getElementById('password').value;
	var val = 0;
	
	var interval = setInterval(function(){
		val = val + 1;
		$('#pb').progressbar({ value: val});
		$('#percent').text(val + '%');
		
		if(val == 100){
			clearInterval(interval);
			window.location.href ="home.php";
		}
		
	}, 50);
	
})