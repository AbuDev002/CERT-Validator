<?php
$i = 0; 
include_once('../db_connect.php'); 
//if(!isset($_GET['q'])){
$query = "SELECT * FROM users ORDER BY uid DESC";  
$result = mysqli_query($conn, $query);
if($rs = mysqli_num_rows($result) > 0){  
while($row = mysqli_fetch_array($result))  
{  
$i++;
?> 
<tr>  
    <td><?php echo $i;?></td>  
    <td><?php echo $row['org_name'];?></td>   
    <td>
      <?php echo $row['username'];?>
    </td>
    <td>
      <?php echo $row['email'];?>
    </td>  
</tr>
<?php 
    } 

}else{
  echo "No record available";
}
?>