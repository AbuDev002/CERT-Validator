<?php
session_start();
	
	require '../helpers/registrationHelpers.php';
	
    $errors = array(
        1=>'Please enter a valid username',
        2=>'Please enter a valid password',
        3=>'Please enter a valid email address',
		4=>'Please complete the form',
		5=>'Certificate already exists',
		6=>'Certificate added successfully!'
    );
	
	$name = 'guest';
	
	if(!isset($_SESSION['username']))
		header('Location:login.php?err=2');
	else
		$name = $_SESSION['username'];
	
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['name'],$_POST['cert_type'],$_POST['dept'],$_POST['cert_no'],$_POST['cert_date']))
		{
			$validCert = validateCert($_POST);
			if($validCert!=0)
				header('Location:index.php?err='.$validUser);
				
			if(!certExists($_POST['cert_no']))
			{
				registerCert($_POST); 
				header('Location:index.php?err=6');
			}
			else {
				header('Location:index.php?err=5');
			}
		}
		else
		{	
			header('Location:login.php?err=4');
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
	
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>

    <div class="container">
             
		<div class="card">

		  <div class="card-header">
		    <?php include_once('incs/inner_nav.php');?>
		  </div>

		  <div class="card-body">
		  	<div class="row gx-5">
		  		<div class="col">
		  			 <div class="p-3 border bg-light">
		  			 		<form class="form-signin" role="form" action="index.php" method="POST">
          <h6 class="form-signin-heading text-center text-muted">Enter Certificate Details</h6>
        <label for="inputUsername" class="sr-only">Name</label>
        <p><input type="text" id="inputUsername" autocomplete="off" class="form-control" placeholder="Name" name="name" required autofocus></p>
        <label for="inputUsername" class="sr-only">Department</label>
        <p>
			<select class="form-control" name="dept">
				<option value="">--Select Department---</option>
				<?php
					$number = mt_rand(100000000,999999999);
					include_once('../db_connect.php');
					$sql = "SELECT * FROM departments";
					$resultset = mysqli_query($conn, $sql) or die("Query Failed:". mysqli_error($conn));
					 while($row = mysqli_fetch_assoc($resultset)){	
				?>
					<option value="<?php echo $row['department'];?>"><?php echo $row['department'];?></option>
				<?php } ?>
			</select>
		</p>
		 <label for="inputUsername" class="sr-only">Program Type</label>
        <p>
			<select class="form-control" name="cert_type">
				<option value="">--Select Program Type---</option>
					<option value="Higher National Diploma">Higher National Diploma</option>
					<option value="Higher Diploma">Higher Diploma</option>
					<option value="National Diploma">National Diploma</option>
					<option value="Diploma">Diploma</option>
					<option value="Certificate">Certificate</option>
			</select>
		</p>
        
        
		
		  			 </div>
		  		</div>


		  		<div class="col">
		  			 <div class="p-3 border bg-light">
		  			 	 <label for="inputUsername" class="sr-only">Program Type</label>
        <p>
			<select class="form-control" name="cert_grade">
				<option value="">--Select Grade---</option>
					<option value="Distinction">Distinction</option>
					<option value="Upper Credit">Upper Credit</option>
					<option value="Lower Credit">Lower Credit</option>
					<option value="Pass">Pass</option>
					
			</select>
		</p>
        <label for="inputEmail" class="sr-only">Student Reg. No.</label>
        <p><input type="text" id="inputEmail" autocomplete="off" class="form-control" placeholder="Reg No..." name="cert_no" value="" required></p>   
		<label for="inputEmail" class="sr-only">QR Code No.</label>
        <p><input type="text" id="inputEmail" autocomplete="off" class="form-control" placeholder="QR Code No..." name="cert_no" value="<?php echo $number;?>" required></p>    
		 <label for="inputEmail" class="sr-only">Certification Date</label>
        <p><input type="date" id="inputEmail" class="form-control" placeholder="Certification Date YYYY-MM-DD" name="cert_date" required></p> 
        <?php if(isset($_GET['err'])){?><p class="text-danger text-center"><?=$errors[$_GET['err']]?></p><?php }?>
        <button class="btn btn-sm btn-success btn-block" type="submit">Add Certificate</button><br>
      </form>  
		  			 </div>
		  		</div>
		  	</div>

		  </div>
		</div>
       

    </div> 
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript" src="script/login.js"></script>
<script src="static/js/typeahead.js"></script>
  </body>
</html>
