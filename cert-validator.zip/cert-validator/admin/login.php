<?php
    session_start(); 
	
	require '../helpers/loginHelpers.php';
	
	    $errors = array(
	        1=>'Username or Password is incorrect!',
	        2=>'Please login before adding user!',
			3=>'Please enter valid username and password!',
			4=>'You have successfully logged out!'
	    );
	
	
	if($_SERVER['REQUEST_METHOD']=='POST') {
		if(isset($_POST['username'],$_POST['password'])) {
			if(checkUser($_POST['username'],$_POST['password'])) {
				$_SESSION['username'] = $_POST['username'];
				header('Location:index.php');
			} else {
				header('Location:login.php?err=1');
			}
		} else {	
			header('Location:login.php?err=3');
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
	
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>
    <div class="container">   
	  	 <div class="row">
		    <div class="col-sm-4">
		      
		    </div>
		    <div class="col-sm-4">
		      	<div class="card">
		      		 <div class="card-header">
					    Cpanel Sign In
					  </div>
		      		<div class="card-body">
		      			 <form class="form-signin" role="form" action="login.php" method="POST">
					        <div class="mb-3">  
					        <label for="inputUsername" class="sr-only">Username</label>
					        <p><input type="text" id="inputUsername" class="form-control" placeholder="Username" name="username" autocomplete="off" required autofocus></p>
					    </div>
					    <div class="mb-3">
					        <label for="inputPassword" class="sr-only">Password</label>
					        <p><input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required></p>
					    </div>
					        <?php if(isset($_GET['err'])){?><p class="text-danger text-center"><?=$errors[$_GET['err']]?></p><?php }?>
					    <div class="mb-3">
					        <button class="btn btn-sm btn-success" type="submit">Sign in</button>
					    </div>
					 </form>
		      			
		      		</div>
		      	</div>
		    </div>
		    <div class="col-sm-4">
		      
		    </div>
		  </div>
                   
		<!-- <center><a href="../">Go Back>></a></center> -->
    </div> 
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript" src="script/login.js"></script>
<script src="static/js/typeahead.js"></script>
  </body>
</html>
