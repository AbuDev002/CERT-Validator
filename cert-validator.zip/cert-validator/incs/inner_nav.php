<ul class="nav nav-tabs card-header-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="true" href="dashboard.php">Dashboard</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" aria-current="true" href="verify_cert.php">Verification</a>
  </li>
  <?php if($_SESSION['account_type'] == "institution"){?>
  	<li class="nav-item">
        <a class="nav-link" aria-current="true" href="upload_result_details.php">Upload Students Result</a>
    </li>
	  <?php } ?>
  <li class="nav-item">
    <a class="nav-link" href="logout.php">Sign Out</a>
  </li>
 
</ul>