<?php
$i = 0; 
include_once('db_connect.php'); 
//if(!isset($_GET['q'])){
$query = "SELECT * FROM certificate_details ORDER BY cert_id DESC";  
$result = mysqli_query($conn, $query);
if($rs = mysqli_num_rows($result) > 0){  
while($row = mysqli_fetch_array($result))  
{  
$i++;
?> 
<tr>  
    <td><?php echo $i;?></td>  
    <td><?php echo $row['name'];?></td>  
    <td>
      <?php 
      $getinstitution = mysqli_query($conn,"select * from institutions where id=".$row["institution_id"]."");
        $inst_name = mysqli_fetch_array($getinstitution);
        echo $inst_name['institution_name'];
      ?>
  
    </td>  
    <td>
      <?php echo $row['matric_no'];?>
    </td>
    <td>
      <?php echo $row['dept'];?>
    </td>  
    <td>
      <?php echo $row['cert_type'];?>
    </td>
    <td>
      <?php echo $row['cert_grade'];?>
    </td>   
    
</tr>
<?php 
    } 

}else{
  echo "No record available";
}
?>