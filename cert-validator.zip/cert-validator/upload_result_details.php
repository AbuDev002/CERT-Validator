<?php
session_start(); 
	require 'helpers/registrationHelpers.php';
include_once("db_connect.php");
$sql = "SELECT uid, username, password, email FROM users WHERE uid='".$_SESSION['user_session']."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);

?>
<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/datatable.min.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="js/adapter.min.js"></script>
<script type="text/javascript" src="js/vue.min.js"></script>
<script type="text/javascript" src="js/instascan.min.js"></script>

</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>

    <div id="app" class="container"> 
    	<div class="card">

		  <div class="card-header">
		    <?php include_once('incs/inner_nav.php');?>
		  </div>

		  <div class="card-body">
		    	<!-- <h2 class="form-signin-heading text-center text-muted">Enter Certificate Details</h2> -->
		    	<!-- <div style="display:none" id="result"><g:plusone size="medium"></g:plusone></div> -->
    	<div class="container overflow-hidden">
		  <div class="row">
		    <div class="col-md-8">
		    	<h3>List of Records</h3>
		    	<table class="table table-bordered"  style="width:100%;">
		    		<thead>
		    			<tr>
			    			<td><strong>S/N</strong></td>
			    			<td><strong>Student Name</strong></td>
			    			<td><strong>Institution</strong></td>
			    			<td><strong>Matric No.</strong></td>
			    			<td><strong>Department</strong></td>
			    			<td><strong>Certificate Type</strong></td>
			    			<td><strong>Grade Obtained</strong></td>
			    		</tr>
		    		</thead>
		    		<tbody id="displayResultListist">
		    			
		    		</tbody>
		    		
		    	</table>
		    </div>
		    <div class="col-md-4">
		    	
		      <div class="p-3 border bg-light">   
		      	<p><strong>Upload Student List</strong></p>
		        <form id="upload_csv" class="form-horizontal"  method="POST" enctype="multipart/form-data">
		        <div class="form-group">
		        	<select id="institution" class="form-control" name="institution">
		        		<option value="">--Select Institution--</option>
		        		<?php 
		        			include_once('db_connect.php');
		        			$getinstitutions = mysqli_query($conn,"SELECT * FROM institutions");
		        			while($row = mysqli_fetch_array($getinstitutions)){
		        		?>
		        			<option value="<?php echo $row['id'];?>"><?php echo $row['institution_name'];?></option>
		        		<?php } ?>
		        	</select>
		        </div>
		        <br>
		        <div class="form-group">
		        	<input type="file"  name="resultFiles" id="resultFiles" class="form-control">
		        </div>
		        <br>
		        <div class="form-group">
		        	<button class="btn btn-sm btn-success btn-block" type="submit">Upload List</button>
		        </div>
		      </form>
               
		      </div>

		    </div>
		  </div>
		</div>
		  
		  </div>
		</div>

    </div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/datatable.js" ></script>
    <script type="text/javascript">
      $('#custom_table').dataTable();
    </script>
<script src="static/js/script.js"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<!-- <script type="text/javascript" src="script/login.js"></script> -->
<!-- <script type="text/javascript" src="js/app.js"></script> -->

<script type="text/javascript">
   //this function is usded in getting list of Results 
   function loadResultList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("displayResultListist").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "fetchResultList.php", true);
        xhttp.send();
      },2000);
    }
    loadResultList();
</script>
<script>  
      $(document).ready(function(){  
           $('#upload_csv').on("submit", function(e){  
                e.preventDefault(); //form will not submitted  
                $.ajax({  
                     url:"import.php",  
                     method:"POST",  
                     data:new FormData(this),  
                     contentType:false,     // The content type used when sending data to the server.  
                     cache:false,                // To unable request pages to be cached  
                     processData:false,   // To send DOMDocument or non processed data file it is set to false  
                     success: function(data){  
                          if(data=='Error1')  
                          {  
                               alert("Invalid File");  
                          }  
                          else if(data == "Error2")  
                          {  
                               alert("Please Select File");  
                          }  
                          else  
                          {  
                              alert("Data Uploaded successfully");  
                          }  
                     }  
                })  
           });  
      });  
 </script>  

</body>
</html>
