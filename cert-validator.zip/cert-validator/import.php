<?php
	if(!empty($_FILES['resultFiles']['name'])){
		include_once('db_connect.php');
		//$output ="";
		$allowed_ext = array("csv");
		$extension = end(explode(".", $_FILES['resultFiles']['name']));
		if(in_array($extension, $allowed_ext)){
			$file_data = fopen($_FILES["resultFiles"]["name"], 'r');
			fgetcsv($file_data);
			while($row = fgetcsv($file_data)){
				$institution = mysqli_real_escape_string($conn, $_POST['institution']);
				$matric_no = mysqli_real_escape_string($conn, $row[0]);
				$name = mysqli_real_escape_string($conn, $row[1]);
				$cert_type = mysqli_real_escape_string($conn, $row[2]);
				$dept = mysqli_real_escape_string($conn, $row[3]);
				$cert_grade = mysqli_real_escape_string($conn, $row[4]);
				$cert_no = mysqli_real_escape_string($conn, $row[5]);
				$cert_date = mysqli_real_escape_string($conn, $row[6]);
				$query = "INSERT INTO certificate_details (institution_id,matric_no,name,cert_type,dept,cert_grade,cert_no,cert_date) VALUES('".$institution."','$matric_no','$name','$cert_type','$dept','$cert_grade','$cert_no','$cert_date')" or die(mysqli_error($conn));
				mysqli_query($conn,$query);
			}
		}else{
			echo "Error1";
		}
	}else{
		echo "Error2";
	}
?>