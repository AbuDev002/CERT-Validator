<?php
	if(isset($_GET['cname']) && isset($_GET['cno'])){
		$cname = $_GET['cname'];
		$ctype = $_GET['ctype'];
		$dept = $_GET['dept'];
		$cno = $_GET['cno'];
		$cdate = $_GET['cdate'];
		$cgrade = $_GET['cgrade'];
	}else{
		header('location:dashboard.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
	<script type="text/javascript">  
        function printDiv() {  
            var divContents = document.getElementById("card").innerHTML;  
            var printWindow = window.open('', '', 'height=500,width=500');  
            printWindow.document.write('<html><head><title>Print DIV Content</title>');  
            printWindow.document.write('</head><body >');  
            printWindow.document.write(divContents);  
            printWindow.document.write('</body></html>');  
            printWindow.document.close();  
            printWindow.print();  
        }  
    </script> 
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>

	<div class="container">
		<input type="button" class="btn btn-primary" value="Print" onclick="printDiv()">
		<div class="card" id="card">

		  <div class="card-header">
		    <ul class="nav nav-tabs card-header-tabs">
		      <li class="nav-item">
		        <a class="nav-link" aria-current="true" href="dashbaord.php">Dashboard</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" aria-current="true" href="verify_cert.php">Verification</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link active" aria-current="true" href="verify_cert.php">Certificate</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="logout.php">Sign Out</a>
		      </li>
		     
		    </ul>
		  </div>

		  <div class="card-body">
		    	
<div style="width:800px; height:900px; padding:20px; margin:0px auto; text-align:center; border: 3px solid #787878;">
		<center><img src="images/polylogo.jpg" width="100" height="100"></center>
		<center><h3>The Federal Polytechnic Bauchi <br> P.M.B 0231</h3></center>
		<div style="width:750px; height:550px; padding:20px; text-align:center; border: 5px solid #787878">
       <span style="font-size:50px; font-weight:bold">Certificate of Completion</span>
       <br><br>
       <span style="font-size:25px"><i>This is to certify that</i></span>
       <br><br>
       <span style="font-size:30px"><b><?php echo $cname; ?></b></span><br/><br/>
       <span style="font-size:25px"><i>having successfully completed an approved course of study in</i></span> <br/><br/>
       <span style="font-size:30px"><?php echo $dept;?></span> <br/><br/>
       <span style="font-size:20px">and has been awarded with <b><?php echo $ctype; ?></b> <br> At <b><?php echo $cgrade;?></b> <br >by the academic board of the institution</span> <br/><br/><br/><br/>
       <span style="font-size:25px"><i>dated</i></span><br>
      	<?php echo date('F j, Y',strtotime($cdate)); ?>
      <!-- <span style="font-size:30px">$dt</span> -->
	  <center><img src="qrcode.php?text=<?php echo $cno;?>&size=70&padding=30" alt="QR Code"></center>
</div>
	<table style="width:100%;">
		<tr>
			<td></td>
			<td style="text-align:right;">
				<h5>MB ABUBAKAR</h5>
				<h6>For: Registrar</h6>
			</td>
		</tr>
	</table>
</div>
		  </div>
		</div>

</div>
	</body>
	 
</html>
