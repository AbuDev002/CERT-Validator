<?php include_once("db_connect.php");?>
<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">

</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>
<div class="container">	
	<div class="row">
		<div class="col-md-6" style="background:url('images/v2.jpg') no-repeat;background-size:cover;">
			
			
		</div>
		<div class="col-md-6">
<form class="form-login" method="post" id="login-form">
		<div id="error"></div>
		
		<div class="mb-3">
		  <label for="user_email" class="form-label">Email address</label>
		  <input type="email" class="form-control" name="user_email" id="user_email" placeholder="name@example.com">
		  <span id="check-e"></span>
		</div>

		<div class="mb-3">
			<!-- <input type="password" class="form-control" placeholder="Password" name="password"  /> -->
			<label for="password" class="form-label">Password</label>
			<input type="password" class="form-control" name="password" id="password" placeholder="Password..."/>
		</div>
		<hr />
		<div class="mb-3">
			<button type="submit" class="btn btn-light" name="login_button" id="login_button">
			<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
			</button> 
		</div>
	<hr/>
		
	</form>		
		</div>
	</div>
	 <br>	
	<small><p class="text-center lh-lg">&copy <?php echo date('Y'); ?> All rights reserved. UAM Cert Verifier</p>	</small>
</div>
<script async src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script async src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script async type="text/javascript" src="script/validation.min.js"></script>
<script async type="text/javascript" src="script/login.js"></script>
<script async src="static/js/typeahead.js"></script>	
<script async src="static/js/script.js"></script>
</body>
</html>