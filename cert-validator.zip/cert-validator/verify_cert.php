<?php
	session_start(); 
	require 'helpers/registrationHelpers.php';
	
    $errors = array(
        1=>'Please enter a valid username',
        2=>'Please enter a valid password',
        3=>'Please enter a valid email address',
		4=>'Please Enter a Certificate No.',
		5=>'This is a Valid Certificate!',
		6=>'No Certificate Record Found!'
    );
	
	$name = 'guest';
	$cert_no='';
	
	
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['cert_no']))
		{
			$validCert = validateCert($_POST);

			if($validCert!=0)
				header('Location:index.php?err='.$validCert);
				
			if(!certExists($_POST['cert_no']))
			{
				header('Location:index.php?err=6');
				echo "<script>alert('Certificate Record Not Found')</script>";
			}
			else {
				
				certDetails($_POST['cert_no']);
				
				
			/*	$_SESSION['cert_no'] = $_POST['cert_no'];
			$cert_no = $_SESSION['cert_no']; */
				header('Location:index.php?err=5');
			}
		}
		else
		{	
			header('Location:index.php?err=4');
		}
		
	}

?>

<?php
include_once("db_connect.php");
$sql = "SELECT uid, username, password, email FROM users WHERE uid='".$_SESSION['user_session']."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);

?>
<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="js/adapter.min.js"></script>
<script type="text/javascript" src="js/vue.min.js"></script>
<script type="text/javascript" src="js/instascan.min.js"></script>
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>

    <div id="app" class="container"> 
    	<div class="card">

		  <div class="card-header">
		   <?php include_once('incs/inner_nav.php');?>
		  </div>

		  <div class="card-body">
		    	<!-- <h2 class="form-signin-heading text-center text-muted">Enter Certificate Details</h2> -->
		    	<!-- <div style="display:none" id="result"><g:plusone size="medium"></g:plusone></div> -->
    	<div class="container overflow-hidden">
		  <div class="row gx-5">
		    <div class="col">
		     <div class="p-3 border bg-light">

		     	<div class="selector" id="webcamimg" onclick="setwebcam()" align="left" /><strong><p class="card-text">Placed your result near your camera for scanning the QR code</p></strong></div>
		     	<div class="card">
				  <!-- <img src="..." class="card-img-top" alt="..."> -->
			
				  <div class="card-body">
				  	
					<!-- <div class="selector" id="qrimg" onclick="setimg()"/>teo</div> -->
				  
				  	<!-- <canvas id="qr-canvas" width="300" height="200"></canvas> -->
				  	<!-- <div id="result"></div> -->
				  	<div class="preview-container">
					  	<video id="preview" style="width:300px;"></video>
					 </div>
				    
				  </div>
				</div>
		     </div>
		    </div>
		    <div class="col">
		    	
		      <div class="p-3 border bg-light">   
		      	<p><strong>Captured QR Code</strong></p>
		        <form class="form-signin" role="form" action="cert.php" method="POST">

		        <p><input type="text"  id="inputEmail" class="form-control" autocomplete="off" placeholder="Captured Qr Code..." name="cert_no" required></p>    
				
				<?php if(isset($_GET['err'])){?><p class="text-danger text-center"><?=$errors[$_GET['err']]?></p><?php }?>
				 <button class="btn btn-sm btn-success btn-block" type="submit">Verify</button>
		      </form>
                <br/>
                 <div class="sidebar">
        <!--<section class="cameras">
          <h2>Cameras</h2>
          <ul>
            <li v-if="cameras.length === 0" class="empty">No cameras found</li>
            <li v-for="camera in cameras">
              <span v-if="camera.id == activeCameraId" :title="formatName(camera.name)" class="active">{{ formatName(camera.name) }}</span>
              <span v-if="camera.id != activeCameraId" :title="formatName(camera.name)">
                <a @click.stop="selectCamera(camera)">{{ formatName(camera.name) }}</a>
              </span>
            </li>
          </ul>
        </section>-->
        <section class="scans">
          <h5>Scanned Code</h5>
          <ul v-if="scans.length === 0">
            <li class="empty">No scans yet</li>
          </ul>
          <transition-group name="scans" tag="ul">
            <li v-for="scan in scans" :key="scan.date" :title="scan.content">{{ scan.content }}</li>
          </transition-group>
        </section>
      </div>
		      </div>

		    </div>
		  </div>
		</div>
		  
		  </div>
		</div>

    </div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript" src="script/login.js"></script>
<script type="text/javascript" src="js/app.js"></script>
  </body>
</html>
