<?php 

if( !session_id() )
{
    session_start();
}

if(@$_SESSION['logged_in'] == true){
    header("Location: home.php");
}
?>

<script type="text/javascript" src="./llqrcode.js"></script>
<script type="text/javascript" src="./plusone.js"></script>
<script type="text/javascript" src="./webqr.js"></script>

<div id="main">
<div id="header">
<div style="display:none" id="result"><g:plusone size="medium"></g:plusone></div>
<p id="mp1">
QR Code scanner
</p>
</div>
<div id="mainbody">
	<table class="tsel" border="0" width="100%">
	<tr>
	<td valign="top" align="center" width="50%">
	<table class="tsel" border="0">
	<tr>
	<div class="selector" id="webcamimg" onclick="setwebcam()" align="left" />
</div>
<div class="selector" id="qrimg" onclick="setimg()" align="right"/></div>
</tr>
<tr><td colspan="2" align="center">
<center id="mainbody">
<div id="outdiv"></div></center></td></tr>
</table>
</td>
</tr>
<tr><td colspan="3" align="center">
<img src="down.png"/>
</td></tr>
<tr><td colspan="3" align="center">
<div id="result"></div>
</td></tr>
</table>
</div>&nbsp;
<div id="footer">
</div>
</div>
<canvas id="qr-canvas" width="800" height="600"></canvas>

<script type="text/javascript">load();</script>
<script src="./jquery-1.11.2.min.js"></script>
