<?php
session_start();
if(!isset($_SESSION['user_session'])){
	header("Location: index.php");
}

include_once("db_connect.php");
$sql = "SELECT uid, username, password, email FROM users WHERE uid='".$_SESSION['user_session']."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$row = mysqli_fetch_assoc($resultset);
?>
<!DOCTYPE html>
<html>
<head>
<title>Certificate Verifier</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
</head>
<body>
<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="images/certverf-logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Certificate Verifier Using QR Code
    </a>
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>
<div class="container">    	
		<div class="card text-center">

		  <div class="card-header">
		    <?php include_once('incs/inner_nav.php');?>
		  </div>

		  <div class="card-body">
		    <h5 class="card-title">Hello, <?php echo $row['username']; ?>&nbsp; <br><br>Welcome to Certificate Verification App.</h5>
		    <p class="card-text"><b>Developed By:</b> Ahmad Abubakar Yusuf 19/8129</p>
		    <a href="verify_cert.php" class="btn btn-primary" id="process">Verify Certificate</a>
		  	<p><center><div id="pb" style="width:400px; height:15px;"></div></center></p>
		  </div>
		</div>
		
    	
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="static/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script type="text/javascript" src="script/validation.min.js"></script>
<script type="text/javascript" src="script/login.js"></script>
<script src="static/js/typeahead.js"></script>

 </body>
</html>	


