-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2018 at 08:04 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cert_validator`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificate_details`
--

CREATE TABLE `certificate_details` (
  `cert_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `cert_type` varchar(100) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `cert_grade` varchar(100) NOT NULL,
  `cert_no` varchar(100) NOT NULL,
  `cert_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `certificate_details`
--

INSERT INTO `certificate_details` (`cert_id`, `name`, `cert_type`, `dept`, `cert_grade`, `cert_no`, `cert_date`) VALUES
(1, 'Ahmad Abubakar Yusuf', 'Higher National Diploma', 'COMPUTER SCIENCE', 'Upper Credit', '803445851', '2018-11-29'),
(2, 'David NDA', 'Higher National Diploma', 'COMPUTER SCIENCE', 'Distinction', '840271983', '2018-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `ID` int(11) NOT NULL,
  `department` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='List of departments in Federal Polytechnic Bauchi';

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`ID`, `department`) VALUES
(1, 'ACCOUNTANCY'),
(2, 'AGRICULTURAL TECHNOLOGY'),
(3, 'AGRICULTURAL AND BIO-ENVIRONMENTAL ENGINEERING/TECHNOLOGY'),
(4, 'ANIMAL HEALTH AND PRODUCTION/ TECHNOLOGY'),
(5, 'ARCHITECTURAL TECHNOLOGY'),
(6, 'BANKING AND FINANCE'),
(7, 'BUILDING TECHNOLOGY'),
(8, 'BUSINESS ADMINISTRATION AND MANAGEMENT'),
(9, 'CIVIL ENGINEERING'),
(10, 'COMPUTER SCIENCE'),
(11, 'CRIME MANAGEMENT AND CONTROL'),
(12, 'ELECTRICAL ELECTRONICS ENGINEERING'),
(13, 'ESTATE MANAGEMENT TECHNOLOGY'),
(14, 'FOOD SCIENCE AND TECHNOLOGY'),
(15, 'GENERAL STUDIES'),
(16, 'HOSPITALITY MANAGEMENT'),
(17, 'MARKETING'),
(18, 'MASS COMMUNICATION'),
(19, 'MATHS AND STATISTICS'),
(20, 'MECHANICAL ENGINEERING'),
(21, 'MECHATRONIC ENGINEERING'),
(23, 'OFFICE TECHNOLOGY AND MANAGEMENT'),
(24, 'PHARMACEUTICAL TECHNOLOGY'),
(25, 'PRE-ND AND REMEDIAL STUDIES'),
(26, 'PUBLIC ADMINISTRATION'),
(27, 'QUANTITY SURVEY'),
(28, 'SCIENCE LABORATORY TECHNOLOGY'),
(29, 'SURVEY AND GEO-INFORMATICS'),
(30, 'NUTRITION AND DIETETICS'),
(31, 'FORESTRY'),
(32, 'ANIMAL HEALTH AND PRODUCTION TECHNOLOGY'),
(33, 'LEISURE AND TOURISM MANAGEMENT'),
(34, 'LIBRARY AND INFORMATION SCIENCE');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `user`, `pass`, `email`) VALUES
(1, 'user1', 'password', 'user1@users.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `city`) VALUES
(1, 'admin', 'password', 'admin@admin.com', 'Bauchi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificate_details`
--
ALTER TABLE `certificate_details`
  ADD PRIMARY KEY (`cert_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department`),
  ADD UNIQUE KEY `UNIQUE` (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `certificate_details`
--
ALTER TABLE `certificate_details`
  MODIFY `cert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
